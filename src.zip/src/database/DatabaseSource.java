package database;
import java.sql.*;

public interface DatabaseSource{

    static final String url = "jdbc:mysql://localhost:3306/cinema";
    static final String username = "root";
    static final String password = "12345678";

}